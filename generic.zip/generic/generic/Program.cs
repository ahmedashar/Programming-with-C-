﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace generic
{
    class Example
    {
        // public static void DisplayData(int a)
        public static void DisplayData<T>(T a)   // <T> --> placeholder for defining a generic methods
        {
            Console.WriteLine( typeof(T) );
        }

        //public static void PrintArray(int[] arr)
        public static void PrintArray<G>(G[] arr) //generic method
        {
            Console.WriteLine("---------------Print Array--------------");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
        }
    }


    // generic class
    class Demo <A>
    {
        //public int item;
        private A item;

        public Demo(A a)
        {
            this.item = a;
        }
        public A Print()
        {
            return this.item;
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            //int x = 20;
            //string name = "Ashar";
            //double number = 20.2;

            //string[] names = { "Owais", "Talha", "Siraj"};
            //int[] ages = { 22,23,24};

            //Example.DisplayData(x);
            //Example.DisplayData(name);
            //Example.DisplayData(number);

            //Example.PrintArray(names);
            //Example.PrintArray(ages);

            Demo<string> D1 = new Demo<string>("Ashar");

            Demo<int> D2 = new Demo<int>(20);

            Console.WriteLine(D2.Print());

            string x = D1.Print();

            Console.WriteLine(x);
        }
    }
}
