﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace getSet
{
    //class Student
    //{
    //    //fields
    //    private string name;
    //    private string age;

    //    //properties
    //    public string Name
    //    {
    //       private get { return name; }
    //       set { name = value; } // call when value is assigned
    //    }

    //}

    //2nd way
    //class Student
    //{
    //    public string Name { private get; set; }
    //    public int Age { get; set; }
    //}



    class Program
    {

        static void Main(string[] args)
        {
            //Student std1 = new Student();
            //std1.Name = "Ashar";

            //Console.WriteLine(std1.Name);




        }
    }
}
