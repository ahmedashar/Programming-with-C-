﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Indexers: Special members of a class that
// allows an object to be accessed like an array.

namespace Indexers
{
    class Empolyee
    {
       private int id;

      private int[] enrollment = new int[5];
                        
                       // E1[0];
        public int this[int index]
        {
            set { enrollment[index] = value; }
            get { return enrollment[index]; }
        }


        public int Id
        {
            set { id = value; }
            get { return id; }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Empolyee E1 = new Empolyee();
            E1[0] = 101;
            E1[1] = 102;
            E1[2] = 103;
            E1[3] = 104;
            E1[4] = 105;

            for (int i = 0; i < 5; i++)
            {
            Console.WriteLine(E1[i]);
                
            }

            Console.ReadKey();
        }
    }
}
