﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace getSet
{
    //class Student
    //{
    //    //fields
    //    private string name;

    //    private string age;

    //    //properties
    //    public string Name
    //    {
    //        get { return name; }
    //      private  set { name = value; } // call when value is assigned
    //    }

    //}

    //2nd way
    //class Student
    //{
    //    public string Name { private get; set; }
    //    public int Age { get; set; }
    //}



    class Program
    {

        static void Main(string[] args)
        {
            //Student std1 = new Student();
            //std1.Name = "ashar";

            //Console.WriteLine(std1.Name);




        }
    }
}
